<?php $__env->startSection('cabezera'); ?>

	<ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
        document.getElementById('logout-form').submit();">SALIR</a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form>
 		</li>
    </ul>  
    <ul class="nav navbar-nav navbar-right">
        <li><a href="almacen">ALMACEN</a></li>
    </ul>    

    <ul class="nav navbar-nav navbar-right">
        <li><a href="reporte">REPORTE</a></li>
    </ul>                                                

    <ul class="nav navbar-nav navbar-right">
        <li><a href="contenido">INICIO</a></li>
    </ul> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('seccion'); ?>
            <section id="service" class="service">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="main_service_area">
                                <div class="main_service_content">
                                    <div class="service_tabe" style="margin-left: 25%">
                                        <!-- Nav tabs -->
                                        

                                        <!--modalAlmacenBebida-->
                                          <div class="modal fade" id="almacen_bebida" role="dialog">
                                            <div class="modal-dialog">
                                            
                                              
                                              <div class="modal-content">
                                                <div class="modal-header">

                                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                  <h4 class="modal-title">Almacén de Bebidas y Otros productos</h4>
                                                
                                                </div>
                                                <div class="modal-body">

                                             <?php echo e(Form::open(array('url' => 'store/'))); ?>                  
                                                    
                                                      <div class="form-group form-inline">
                                                
                                                        <table class='table table-bordered table-striped table-hover table-responsive tbl-fecio' style="margin-top: 100px">
                                                          
                                                          <thead class="col-tab">
                                                            <td>Nombre</td>
                                                            <td>Cantidad</td>
                                                            <td>Precio</td>
                                                          </thead>
                                                          <tbody>
                                                          <?php $__currentLoopData = $bebidasYOtros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
      
                                                              <td><?php echo e($result->descripcion); ?></td>
                                                              <td><?php echo e($result->cantidad); ?></td>
                                                              <td><?php echo e($result->precio); ?></td>

                                                            </tr> 
                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                           
                                                          </tbody>
                                                        </table>
                                                      </div><br/>
                                                               
                                                    
                                                                                                    
                                                </div>
                                                <div class="modal-footer">
                                                  <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                                                </div>
                                                <?php echo e(Form::close()); ?>

                                              </div>
                                              
                                            </div>
                                          </div>
                                         <!--endmodalAlmacenBebida-->                                         

                                        <!--modalAlmacenComida-->
                                          <div class="modal fade" id="almacen_comida" role="dialog">
                                            <div class="modal-dialog">
                                            
                                              
                                              <div class="modal-content">
                                                <div class="modal-header">

                                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                  <h4 class="modal-title">Almacén de Comestibles</h4>
                                                
                                                </div>
                                                <div class="modal-body">

                                             <?php echo e(Form::open(array('url' => 'store/'))); ?>                  
                                                    
                                                      <div class="form-group form-inline">
                                                        <table class='table table-bordered table-striped table-hover table-responsive tbl-fecio' style="margin-top: 100px">
                                                          
                                                          <thead class="col-tab">
                                                            <td>Nombre</td>
                                                            <td>Cantidad</td>
                                                            <td>Precio</td>
                                                          </thead>
                                                          <tbody>
                                                          <?php $__currentLoopData = $comidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
      
                                                              <td><?php echo e($result->descripcion); ?></td>
                                                              <td><?php echo e($result->cantidad); ?></td>
                                                              <td><?php echo e($result->precio); ?></td>

                                                            </tr> 
                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                           
                                                          </tbody>
                                                        </table>
                                                      </div><br/>
                                                               
                                                    
                                                                                                    
                                                </div>
                                                <div class="modal-footer">
                                                  <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                                                </div>
                                                <?php echo e(Form::close()); ?>

                                              </div>
                                              
                                            </div>
                                          </div>
                                         <!--endmodalAlmacenComida-->                                         


                                        <ul class="service_tabe_menu nav nav-tabs" role="tablist">
                                            
                                            <a href="#" aria-controls="webdesign" role="tab"><li role="presentation" data-toggle="modal" data-target="#almacen_bebida"><i class=" glyphicon glyphicon-glass"></i> <br />Bebidas</a></li>

                                            <a href="#" aria-controls="webdesign" role="tab"><li role="presentation" data-toggle="modal" data-target="#almacen_comida"><i class="glyphicon glyphicon-cutlery"></i> <br />Comestibles</a></li>
 
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>