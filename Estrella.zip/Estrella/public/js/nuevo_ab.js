$(document).ready(function(){
	$("#nuevo_ab").click(function(){
		$("#des_ab").val("Seleccione...");
		$("#cant_ab").val('');
		$("#precio_ab").val("");
		$("#fecha_ab").val("Seleccione...");
	});
});