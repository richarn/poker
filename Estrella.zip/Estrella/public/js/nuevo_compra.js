$(document).ready(function(){
	$("#nuevo_comp").click(function(){
		$("#comp").val("");
		$("#fecha_com").val("");
		
	});
});