$(document).ready(function(){
	$("#nuevo2").click(function(){
		$("#venta_come").val("Seleccione...");
		$("#cantidad_vc").val('Seleccione...');
		$("#precio_vc").val("Seleccione...");
		$("#fecha_vc").val("Seleccione...");
	});
});