$(document).ready(function(){
	$("#nuevo_pozo").click(function(){
		$("#pozo_").val("");
		$("#propina").val('');
		$("#fecha_pz").val("");
		
	});
});