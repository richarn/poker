$(document).ready(function(){
	$("#nuevo_Rbebida").click(function(){
		$("#des_rb").val("");
		$("#cant_rb").val('');
		$("#precio_rb").val("");
		$("#fecha_rb").val("Seleccione...");
	});
});