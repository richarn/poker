$(document).ready(function(){
	$("#nuevo_bi").click(function(){
		$("#bill").val("");
		$("#precio_bi").val('');
		$("#precio_ac").val("");
		$("#fecha_bi").val("");
	});
});