$(document).ready(function(){
	$("#nuevo1").click(function(){
		$("#venta_bebi").val("Seleccione...");
		$("#cantidad_vb").val('Seleccione...');
		$("#precio_vb").val("Seleccione...");
		$("#fecha_vb").val("Seleccione...");
	});
});