$(document).ready(function(){
	$("#nuevo_rc").click(function(){
		$("#des_rc").val("");
		$("#can_rc").val('');
		$("#precio_rc").val("");
		$("#fecha_rc").val("Seleccione...");
	});
});