$(document).ready(function(){
	$("#nuevo_ac").click(function(){
		$("#des_ac").val("");
		$("#can_ac").val('');
		$("#precio_ac").val("");
		$("#fecha_ac").val("Seleccione...");
	});
});